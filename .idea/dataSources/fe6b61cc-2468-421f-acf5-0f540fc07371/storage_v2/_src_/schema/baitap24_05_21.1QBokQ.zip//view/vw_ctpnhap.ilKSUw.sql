create definer = root@localhost view vw_ctpnhap as
select count(0)                                     AS `Số phiếu nhập hàng`,
       `ctpn`.`vattu_id`                            AS `Mã vật tư`,
       `ctpn`.`soluongnhap`                         AS `Số lượng nhập`,
       `ctpn`.`dongianhap`                          AS `Đơn giá nhập`,
       (`ctpn`.`soluongnhap` * `ctpn`.`dongianhap`) AS `Thành tiền nhập`
from `baitap24_05_21`.`chitietphieunhap` `ctpn`
group by `ctpn`.`phieunhap_id`;

