create definer = root@localhost view showstudentinfoandmark as
select `s`.`StudentID` AS `ID`, `s`.`StudentName` AS `Tên Học sinh`, `m`.`Mark` AS `Điểm`
from (`baitap20_05_21`.`student` `s`
         join `baitap20_05_21`.`mark` `m` on ((`s`.`StudentID` = `m`.`StudentID`)));

